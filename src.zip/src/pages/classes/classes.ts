import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { ProgramdetailsPage } from "../programdetails/programdetails";
import { ClassdetailsPage } from "../classdetails/classdetails";
import { BookPage } from "../book/book";
import { Storage } from '@ionic/storage';
import { Http } from "@angular/http";
import 'rxjs/add/operator/map';
import { SpinnerDialog } from '@ionic-native/spinner-dialog';

/**
 * Generated class for the ClassesPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-classes',
  templateUrl: 'classes.html',
})
export class ClassesPage {
  myZayed: any;
  myMaadi: any;
  zayed: any;
  maadi: any;
  choice: string;
  classes: any;

  constructor(public navCtrl: NavController, public navParams: NavParams,public http:Http,public spinnerDialog:SpinnerDialog) {
    this.choice = 'Cairo';
    this.myMaadi=[];
    this.myZayed=[];
  }
  pickDate(e) {
    this.myMaadi=e.Maadi;
    this.myZayed=e.Zayed;
    for (var x = 0; x < this.classes.length; x++) {
      this.classes[x].color = 'primary'
    }
    e.color = "light";
    console.log(e.day, e.date);
  }
  ionViewDidEnter() {
    console.log('ionViewDidLoad AllprogramsPage');
    this.spinnerDialog.show('Loading...');
    this.http.get('http://artcafe.bit68.com/classes').map(res => res.json()).subscribe(data => {
      this.spinnerDialog.hide();
      console.log(data);
      for(var x=0;x<data.length;x++){
        data[x].color="primary";
        this.classes=data;
      }
      // this.maadi=data.Maadi;
      // this.zayed=data.Zayed;
    }, err => {
      console.log(err);
      this.spinnerDialog.hide();
      alert(err);
    });
  }
  progDet(e) {
    this.navCtrl.push(ProgramdetailsPage, { data: e });
  }
  goDet(c) {
    this.navCtrl.push(ClassdetailsPage, { data: c });
  }
  goBook(s) {
    this.navCtrl.push(ClassdetailsPage, { data: s });
  }

}
