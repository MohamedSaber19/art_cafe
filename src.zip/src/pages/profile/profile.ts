import { Component } from '@angular/core';
import { NavController, NavParams, Events } from 'ionic-angular';
import { Http } from "@angular/http";
import 'rxjs/add/operator/map';
import { Storage } from '@ionic/storage';
import { SpinnerDialog } from '@ionic-native/spinner-dialog';

/**
 * Generated class for the ProfilePage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */

@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html',
})
export class ProfilePage {
  noNotifs: boolean;
  noStudios: boolean;
  noBooks: boolean;
  myInfo: any={
    club_bookings:[],
    class_bookings:[]
  };
  user_info: any={};
  choice: string="History";
  

  constructor(public navCtrl: NavController, public storage: Storage, public navParams: NavParams, public events: Events, public http: Http,public spinnerDialog:SpinnerDialog) {
    // this.choice = "History";
    // this.user_info = {};
    // this.myInfo={};

  }

  ionViewDidEnter() {
  this.spinnerDialog.show('Loading...');
    console.log('ionViewDidLoad ProfilePage');
    this.storage.get('user_info').then((val) => {
      this.user_info = JSON.parse(val);
      console.log(this.user_info);
      this.http.get('http://artcafe.bit68.com/user_info/?token=' + this.user_info.token).map(res => res.json()).subscribe(data => {
        this.spinnerDialog.hide();
        this.myInfo = data;
        if(data.class_bookings.length==0){
          this.noBooks=true;
        }else{
          this.noBooks=false;
        }
        if(data.club_bookings.length==0){
          this.noStudios=true;
        }else{
          this.noStudios=false;
        }
        if(data.notifications.length==0){
          this.noNotifs=true;
        }else{
          this.noNotifs=false;
        }
        console.log('updated info' , data);
      }, err => {
        this.spinnerDialog.hide();
        console.log(err);
        alert(err);
      })
    })
    
  }

}
